library(shiny)
library(DT)
library(pacman)
library(stringr)

mainCategoriesList <- c("gdp",
                        "consumption",
                        "capital",
                        "government expenditures",
                        "exports",
                        "imports")

gdpList <- c("gdp")

consumptionList <- c("consumption",
                     "taxes",
                     "employment rate",
                     "exchange rate",
                     "wage growth",
                     "disposable income",
                     "household credit")

capitalList <- c("capital",
                 "housing starts",
                 "residential construction",
                 "non-residential construction investments",
                 "machinery investments")

governmentExpendituresList <- c("government expenditure")

importsExportsList <- c("monthly real",
                        "farm and fishing",
                        "energy",
                        "metal ores and minerals",
                        "metal products",
                        "industrial production",
                        "forestry",
                        "industrial m&e",
                        "electronic equipment",
                        "motor vehicles and parts",
                        "aircrafts",
                        "consumer goods")


addSlider <- function(number, minValue, maxValue) {
  name <- paste("range", number, sep = "_")
  sliderInput(name, "What is the timeframe to display?", 
              min = minValue, max = maxValue, value = c(minValue,maxValue))
}

performForecasting <- function(number) {
  name <- paste("forecastBox", number, sep = "_")
  checkboxInput(name, strong("Would you like to perform forecasting?"), value = FALSE)
}

selectForecastLength <- function(number) {
  name <- paste("forecastLength", number, sep = "_")
  sliderInput(name, "How many years ahead?",
              min = 1, max = 3, value = 1)
}

ui <- fluidPage(
  fluidRow(
    column(width = 3,
           HTML('<center><img src="GOC_colour_en.jpg" height="27.333" width="260.667" vspace="70"></center>')),
    column(width = 6,
           h1("CanDev - Finance Canada", 
              style = "font-family: 'Helvetica Neue';
              font-weight: 800;
              line-height: 1.1;
              color: #fff; text-align: center;
              background-image: url('bg.png');
              padding: 40px")),
    column(width = 3,
           HTML('<center><img src="Canwordmark_colour.jpg" height="58.5" width="224" vspace="55"></center>'))
  ),
  
  
  
  tags$head(tags$style(HTML(".shiny-text-output {background-color:#fff;}"))),
  
  # h1("CanDev - Finance Canada", 
  #    style = "font-family: 'Helvetica Neue';
  #    font-weight: 800;
  #    line-height: 1.1;
  #    color: #fff; text-align: center;
  #    background-image: url('bg.png');
  #    padding: 40px"),
  tags$hr(),
  
  
  sidebarPanel(
    width = 4,
    selectInput(inputId = "mainCategories",
                label = strong("Which major Category are you looking for?"),
                choices = mainCategoriesList),
    
    conditionalPanel(condition = "input.mainCategories == 'gdp'",
                     selectInput(inputId = "gdp",
                                 label = strong("Which GDP subsection?"),
                                 choices = gdpList),
                     tags$br(),
                     conditionalPanel(condition = "input.gdp == 'gdp'",
                                      addSlider("1", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(), 
                                      #addfrequency(),
                                      tags$br(),
                                      performForecasting("1"),
                                      conditionalPanel(condition = "input.forecastBox_1",
                                                       selectForecastLength("1")))),
    
    conditionalPanel(condition = "input.mainCategories == 'consumption'",
                     selectInput(inputId = "consumption",
                                 label = strong("Which Consumption subsection?"),
                                 choices = consumptionList),
                     tags$br(),
                     conditionalPanel(condition = "input.consumption == 'consumption'",
                                      addSlider("2", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("2"),
                                      conditionalPanel(condition = "input.forecastBox_2",
                                                       selectForecastLength("2"))),
                     
                     conditionalPanel(condition = "input.consumption == 'taxes'",
                                      addSlider("3", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("3"),
                                      conditionalPanel(condition = "input.forecastBox_3",
                                                       selectForecastLength("3"))),
                     
                     conditionalPanel(condition = "input.consumption == 'employment rate'",
                                      addSlider("4", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("4"),
                                      conditionalPanel(condition = "input.forecastBox_4",
                                                       selectForecastLength("4"))),
                     
                     conditionalPanel(condition = "input.consumption == 'exchange rate'",
                                      addSlider("5", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("5"),
                                      conditionalPanel(condition = "input.forecastBox_5",
                                                       selectForecastLength("5"))),
                     
                     conditionalPanel(condition = "input.consumption == 'wage growth'",
                                      addSlider("6", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("6"),
                                      conditionalPanel(condition = "input.forecastBox_6",
                                                       selectForecastLength("6"))),
                     
                     conditionalPanel(condition = "input.consumption == 'disposable income'",
                                      addSlider("7", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("7"),
                                      conditionalPanel(condition = "input.forecastBox_7",
                                                       selectForecastLength("7"))),
                     
                     conditionalPanel(condition = "input.consumption == 'household credit'",
                                      addSlider("8", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("8"),
                                      conditionalPanel(condition = "input.forecastBox_8",
                                                       selectForecastLength("8")))
    ),
    
    conditionalPanel(condition = "input.mainCategories == 'capital'",
                     selectInput(inputId = "capital",
                                 label = strong("Which Capital subsection?"),
                                 choices = capitalList),
                     tags$br(),
                     conditionalPanel(condition = "input.capital == 'capital'",
                                      addSlider("9", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("9"),
                                      conditionalPanel(condition = "input.forecastBox_9",
                                                       selectForecastLength("9"))),
                     
                     conditionalPanel(condition = "input.capital == 'housing starts'",
                                      addSlider("10", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("10"),
                                      conditionalPanel(condition = "input.forecastBox_10",
                                                       selectForecastLength("10"))),
                     
                     conditionalPanel(condition = "input.capital == 'residential construction'",
                                      addSlider("11", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("11"),
                                      conditionalPanel(condition = "input.forecastBox_11",
                                                       selectForecastLength("11"))),
                     
                     conditionalPanel(condition = "input.capital == 'non-residential construction investments'",
                                      addSlider("12", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("12"),
                                      conditionalPanel(condition = "input.forecastBox_12",
                                                       selectForecastLength("12"))),
                     
                     conditionalPanel(condition = "input.capital == 'machinery investments'",
                                      addSlider("13", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("13"),
                                      conditionalPanel(condition = "input.forecastBox_13",
                                                       selectForecastLength("13")))),
    
    conditionalPanel(condition = "input.mainCategories == 'government expenditures'",
                     selectInput(inputId = "governmentExpenditures",
                                 label = strong("Which Government Expenditure subsection?"),
                                 choices = governmentExpendituresList),
                     tags$br(),
                     conditionalPanel(condition = "input.governmentExpenditures == 'government expenditures'",
                                      addSlider("14", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("14"),
                                      conditionalPanel(condition = "input.forecastBox_14",
                                                       selectForecastLength("14")))),
    
    conditionalPanel(condition = "input.mainCategories == 'exports'",
                     selectInput(inputId = "exports",
                                 label = strong("Which Exports subsection?"),
                                 choices = importsExportsList),
                     tags$hr(),
                     conditionalPanel(condition = "input.exports == 'monthly real'",
                                      addSlider("15", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("15"),
                                      conditionalPanel(condition = "input.forecastBox_15",
                                                       selectForecastLength("15"))),
                     
                     conditionalPanel(condition = "input.exports == 'farm and fishing'",
                                      addSlider("16", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("16"),
                                      conditionalPanel(condition = "input.forecastBox_16",
                                                       selectForecastLength("16"))),
                     
                     conditionalPanel(condition = "input.exports == 'energy'",
                                      addSlider("17", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("17"),
                                      conditionalPanel(condition = "input.forecastBox_17",
                                                       selectForecastLength("17"))),
                     
                     conditionalPanel(condition = "input.exports == 'metal ores and minerals'",
                                      addSlider("18", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("18"),
                                      conditionalPanel(condition = "input.forecastBox_18",
                                                       selectForecastLength("18"))),
                     
                     conditionalPanel(condition = "input.exports == 'metal products'",
                                      addSlider("19", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("19"),
                                      conditionalPanel(condition = "input.forecastBox_19",
                                                       selectForecastLength("19"))),
                     
                     conditionalPanel(condition = "input.exports == 'industrial production'",
                                      addSlider("20", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("20"),
                                      conditionalPanel(condition = "input.forecastBox_20",
                                                       selectForecastLength("20"))),
                     
                     conditionalPanel(condition = "input.exports == 'forestry'",
                                      addSlider("21", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("21"),
                                      conditionalPanel(condition = "input.forecastBox_21",
                                                       selectForecastLength("21"))),
                     
                     conditionalPanel(condition = "input.exports == 'industrial m&e'",
                                      addSlider("22", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("22"),
                                      conditionalPanel(condition = "input.forecastBox_22",
                                                       selectForecastLength("22"))),
                     
                     conditionalPanel(condition = "input.exports == 'electronic equipment'",
                                      addSlider("23", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("23"),
                                      conditionalPanel(condition = "input.forecastBox_23",
                                                       selectForecastLength("23"))),
                     
                     conditionalPanel(condition = "input.exports == 'motor vehicles and parts'",
                                      addSlider("24", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("24"),
                                      conditionalPanel(condition = "input.forecastBox_24",
                                                       selectForecastLength("24"))),
                     
                     conditionalPanel(condition = "input.exports == 'aircrafts'",
                                      addSlider("25", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("25"),
                                      conditionalPanel(condition = "input.forecastBox_25",
                                                       selectForecastLength("25"))),
                     
                     conditionalPanel(condition = "input.exports == 'consumer goods'",
                                      addSlider("26", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("26"),
                                      conditionalPanel(condition = "input.forecastBox_26",
                                                       selectForecastLength("26")))),
    
    conditionalPanel(condition = "input.mainCategories == 'imports'",
                     selectInput(inputId = "imports",
                                 label = strong("Which Imports subsection?"),
                                 choices = importsExportsList),
                     tags$hr(),
                     conditionalPanel(condition = "input.imports == 'monthly real'",
                                      addSlider("27", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("27"),
                                      conditionalPanel(condition = "input.forecastBox_27",
                                                       selectForecastLength("27"))),
                     
                     conditionalPanel(condition = "input.imports == 'farm and fishing'",
                                      addSlider("28", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("28"),
                                      conditionalPanel(condition = "input.forecastBox_28",
                                                       selectForecastLength("28"))),
                     
                     conditionalPanel(condition = "input.imports == 'energy'",
                                      addSlider("29", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("29"),
                                      conditionalPanel(condition = "input.forecastBox_29",
                                                       selectForecastLength("29"))),
                     
                     conditionalPanel(condition = "input.imports == 'metal ores and minerals'",
                                      addSlider("30", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("30"),
                                      conditionalPanel(condition = "input.forecastBox_30",
                                                       selectForecastLength("30"))),
                     
                     conditionalPanel(condition = "input.imports == 'metal products'",
                                      addSlider("31", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("31"),
                                      conditionalPanel(condition = "input.forecastBox_31",
                                                       selectForecastLength("31"))),
                     
                     conditionalPanel(condition = "input.imports == 'industrial production'",
                                      addSlider("32", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("32"),
                                      conditionalPanel(condition = "input.forecastBox_32",
                                                       selectForecastLength("32"))),
                     
                     conditionalPanel(condition = "input.imports == 'forestry'",
                                      addSlider("33", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("33"),
                                      conditionalPanel(condition = "input.forecastBox_33",
                                                       selectForecastLength("33"))),
                     
                     conditionalPanel(condition = "input.imports == 'industrial m&e'",
                                      addSlider("34", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("34"),
                                      conditionalPanel(condition = "input.forecastBox_34",
                                                       selectForecastLength("34"))),
                     
                     conditionalPanel(condition = "input.imports == 'electronic equipment'",
                                      addSlider("35", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("35"),
                                      conditionalPanel(condition = "input.forecastBox_35",
                                                       selectForecastLength("35"))),
                     conditionalPanel(condition = "input.imports == 'motor vehicles and parts'",
                                      addSlider("36", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("36"),
                                      conditionalPanel(condition = "input.forecastBox_36",
                                                       selectForecastLength("36"))),
                     
                     conditionalPanel(condition = "input.imports == 'aircrafts'",
                                      addSlider("37", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("37"),
                                      conditionalPanel(condition = "input.forecastBox_37",
                                                       selectForecastLength("37"))),
                     
                     conditionalPanel(condition = "input.imports == 'consumer goods'",
                                      addSlider("38", as.Date("1920-01-01"), as.Date("2025-12-31")),
                                      tags$br(),
                                      performForecasting("38"),
                                      conditionalPanel(condition = "input.forecastBox_38",
                                                       selectForecastLength("38"))))
  ),
  
  mainPanel(
    tabsetPanel(type = "tabs",
                tabPanel("Yearly",value=1,
                         tags$br(),
                         downloadButton('download1', 'Download Yearly Data'),
                         textOutput("text1"),
                         plotOutput("plot1"),
                         tableOutput("tableData1")),
                tabPanel("Quarterly",value=2,
                         tags$br(),
                         downloadButton('download2', 'Download Quarterly Data'),
                         textOutput("text2"),
                         plotOutput("plot2"),
                         tableOutput("tableData2")),
                tabPanel("Monthly",value=3,
                         tags$br(),
                         downloadButton('download3', 'Download Monthly Data'),
                         textOutput("text3"),
                         plotOutput("plot3"),
                         tableOutput("tableData3")),
                id="tabselected")
    
  )
  
)



server <- function(input,output,session) {
  data <- read.table("~/Downloads/output.csv", header = TRUE, sep = ",", stringsAsFactors = FALSE, check.names = FALSE)
  
  commands1 <- reactive({
    mainCategory <- input$mainCategories
    
    subset_table <- data.frame(subset(data, category == mainCategory))
    
    if (mainCategory == "gdp") {
      indicator <- input$gdp
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      updateSliderInput(session, "range_1",
                        min = min(as.Date(subset_table_1$date)),
                        max = max(as.Date(subset_table_1$date)))
      dateRange <- input$range_1
      subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
      subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
    }
    if (mainCategory == "consumption") {
      indicator <- input$consumption
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      if (indicator == "consumption") {
        updateSliderInput(session, "range_2",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_2
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "taxes") {
        updateSliderInput(session, "range_3",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_3
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "employment rate") {
        updateSliderInput(session, "range_4",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_4
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "exchange rate") {
        updateSliderInput(session, "range_5",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_5
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "wage growth") {
        updateSliderInput(session, "range_6",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_6
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "disposable income") {
        updateSliderInput(session, "range_7",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_7
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "household credit") {
        updateSliderInput(session, "range_8",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_8
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
    }  
    if (mainCategory == "capital") {
      indicator <- input$capital
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      if (indicator == "capital") {
        updateSliderInput(session, "range_9",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_9
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "housing starts") {
        updateSliderInput(session, "range_10",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_10
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "residential construction") {
        updateSliderInput(session, "range_11",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_11
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "non-residential construction investments") {
        updateSliderInput(session, "range_12",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_12
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "machinery investments") {
        updateSliderInput(session, "range_13",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_13
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
    }
    if (mainCategory == "government expenditures") {
      indicator <- input$governmentExpenditures
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      updateSliderInput(session, "range_14",
                        min = min(as.Date(subset_table_1$date)),
                        max = max(as.Date(subset_table_1$date)))
      dateRange <- input$range_14
      subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
      subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
    }
    
    if (mainCategory == "exports") {
      indicator <- input$exports
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      if (indicator == "monthly real") {
        updateSliderInput(session, "range_15",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_15
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "farm and fishing") {
        updateSliderInput(session, "range_16",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_16
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "energy") {
        updateSliderInput(session, "range_17",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_17
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "metal ores and minerals") {
        updateSliderInput(session, "range_18",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_18
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "metal products") {
        updateSliderInput(session, "range_19",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_19
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "industrial production") {
        updateSliderInput(session, "range_20",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_20
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "forestry") {
        updateSliderInput(session, "range_21",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_21
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "industrial m&e") {
        updateSliderInput(session, "range_22",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_22
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "electronic equipment") {
        updateSliderInput(session, "range_23",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_23
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "motor vehicles and parts") {
        updateSliderInput(session, "range_24",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_24
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "aircrafts") {
        updateSliderInput(session, "range_25",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_25
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "consumer goods") {
        updateSliderInput(session, "range_26",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_20
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
    }
    
    if (mainCategory == "imports") {
      indicator <- input$imports
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      if (indicator == "monthly real") {
        updateSliderInput(session, "range_27",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_27
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "farm and fishing") {
        updateSliderInput(session, "range_28",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_28
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "energy") {
        updateSliderInput(session, "range_29",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_29
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "metal ores and minerals") {
        updateSliderInput(session, "range_30",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_30
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "metal products") {
        updateSliderInput(session, "range_31",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_31
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "industrial production") {
        updateSliderInput(session, "range_32",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_32
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "forestry") {
        updateSliderInput(session, "range_33",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_33
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "industrial m&e") {
        updateSliderInput(session, "range_34",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_34
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "electronic equipment") {
        updateSliderInput(session, "range_35",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_35
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "motor vehicles and parts") {
        updateSliderInput(session, "range_36",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_36
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "aircrafts") {
        updateSliderInput(session, "range_37",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_37
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "consumer goods") {
        updateSliderInput(session, "range_38",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_38
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
    }
    
    subset_table_1 <- subset(subset_table_1, frequency == "ANNUALLY")
    subset_table_1 <- subset_table_1[,c(4,1)]
    subset_table_1$date <- as.Date(subset_table_1$date, format="%Y")
    subset_table_1$date <- as.integer(substring(subset_table_1$date,1,4))
    
    subset_table_1 <- subset_table_1[rev(order(subset_table_1$date)),]
    
    data_table <- subset_table_1
    
    
    list(subset_table=subset_table_1, data_table=data_table)
    
    
    
  })
  
  commands2 <- reactive({
    mainCategory <- input$mainCategories
    
    subset_table <- data.frame(subset(data, category == mainCategory))
    
    if (mainCategory == "gdp") {
      indicator <- input$gdp
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      updateSliderInput(session, "range_1",
                        min = min(as.Date(subset_table_1$date)),
                        max = max(as.Date(subset_table_1$date)))
      dateRange <- input$range_1
      subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
      subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
    }
    if (mainCategory == "consumption") {
      indicator <- input$consumption
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      if (indicator == "consumption") {
        updateSliderInput(session, "range_2",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_2
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "taxes") {
        updateSliderInput(session, "range_3",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_3
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "employment rate") {
        updateSliderInput(session, "range_4",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_4
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "exchange rate") {
        updateSliderInput(session, "range_5",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_5
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "wage growth") {
        updateSliderInput(session, "range_6",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_6
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "disposable income") {
        updateSliderInput(session, "range_7",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_7
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "household credit") {
        updateSliderInput(session, "range_8",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_8
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
    }  
    if (mainCategory == "capital") {
      indicator <- input$capital
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      if (indicator == "capital") {
        updateSliderInput(session, "range_9",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_9
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "housing starts") {
        updateSliderInput(session, "range_10",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_10
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "residential construction") {
        updateSliderInput(session, "range_11",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_11
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "non-residential construction investments") {
        updateSliderInput(session, "range_12",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_12
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "machinery investments") {
        updateSliderInput(session, "range_13",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_13
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
    }
    if (mainCategory == "government expenditures") {
      indicator <- input$governmentExpenditures
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      updateSliderInput(session, "range_14",
                        min = min(as.Date(subset_table_1$date)),
                        max = max(as.Date(subset_table_1$date)))
      dateRange <- input$range_14
      subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
      subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
    }
    
    if (mainCategory == "exports") {
      indicator <- input$exports
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      if (indicator == "monthly real") {
        updateSliderInput(session, "range_15",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_15
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "farm and fishing") {
        updateSliderInput(session, "range_16",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_16
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "energy") {
        updateSliderInput(session, "range_17",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_17
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "metal ores and minerals") {
        updateSliderInput(session, "range_18",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_18
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "metal products") {
        updateSliderInput(session, "range_19",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_19
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "industrial production") {
        updateSliderInput(session, "range_20",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_20
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "forestry") {
        updateSliderInput(session, "range_21",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_21
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "industrial m&e") {
        updateSliderInput(session, "range_22",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_22
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "electronic equipment") {
        updateSliderInput(session, "range_23",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_23
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "motor vehicles and parts") {
        updateSliderInput(session, "range_24",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_24
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "aircrafts") {
        updateSliderInput(session, "range_25",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_25
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "consumer goods") {
        updateSliderInput(session, "range_26",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_20
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
    }
    
    if (mainCategory == "imports") {
      indicator <- input$imports
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      if (indicator == "monthly real") {
        updateSliderInput(session, "range_27",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_27
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "farm and fishing") {
        updateSliderInput(session, "range_28",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_28
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "energy") {
        updateSliderInput(session, "range_29",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_29
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "metal ores and minerals") {
        updateSliderInput(session, "range_30",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_30
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "metal products") {
        updateSliderInput(session, "range_31",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_31
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "industrial production") {
        updateSliderInput(session, "range_32",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_32
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "forestry") {
        updateSliderInput(session, "range_33",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_33
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "industrial m&e") {
        updateSliderInput(session, "range_34",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_34
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "electronic equipment") {
        updateSliderInput(session, "range_35",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_35
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "motor vehicles and parts") {
        updateSliderInput(session, "range_36",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_36
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "aircrafts") {
        updateSliderInput(session, "range_37",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_37
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "consumer goods") {
        updateSliderInput(session, "range_38",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_38
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
    }
    
    subset_table_1 <- subset(subset_table_1, frequency == "QUARTERLY")
    subset_table_1 <- subset_table_1[,c(4,1)]
    subset_table_1 <- subset_table_1[rev(order(subset_table_1$date)),]
    
    data_table <- subset_table_1
    data_table$date <- as.character(data_table$date)
    data_table$date <- gsub("-01-01", "_Q1", data_table$date)
    data_table$date <- gsub("-04-01", "_Q2", data_table$date)
    data_table$date <- gsub("-07-01", "_Q3", data_table$date)
    data_table$date <- gsub("-10-01", "_Q4", data_table$date)
    
    list(subset_table=subset_table_1, data_table=data_table)
  })
  
  commands3 <- reactive({
    mainCategory <- input$mainCategories
    
    subset_table <- data.frame(subset(data, category == mainCategory))
    
    if (mainCategory == "gdp") {
      indicator <- input$gdp
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      updateSliderInput(session, "range_1",
                        min = min(as.Date(subset_table_1$date)),
                        max = max(as.Date(subset_table_1$date)))
      dateRange <- input$range_1
      subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
      subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
    }
    if (mainCategory == "consumption") {
      indicator <- input$consumption
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      if (indicator == "consumption") {
        updateSliderInput(session, "range_2",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_2
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "taxes") {
        updateSliderInput(session, "range_3",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_3
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "employment rate") {
        updateSliderInput(session, "range_4",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_4
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "exchange rate") {
        updateSliderInput(session, "range_5",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_5
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "wage growth") {
        updateSliderInput(session, "range_6",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_6
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "disposable income") {
        updateSliderInput(session, "range_7",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_7
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "household credit") {
        updateSliderInput(session, "range_8",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_8
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
    }  
    if (mainCategory == "capital") {
      indicator <- input$capital
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      if (indicator == "capital") {
        updateSliderInput(session, "range_9",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_9
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "housing starts") {
        updateSliderInput(session, "range_10",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_10
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "residential construction") {
        updateSliderInput(session, "range_11",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_11
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "non-residential construction investments") {
        updateSliderInput(session, "range_12",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_12
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "machinery investments") {
        updateSliderInput(session, "range_13",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_13
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
    }
    if (mainCategory == "government expenditures") {
      indicator <- input$governmentExpenditures
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      updateSliderInput(session, "range_14",
                        min = min(as.Date(subset_table_1$date)),
                        max = max(as.Date(subset_table_1$date)))
      dateRange <- input$range_14
      subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
      subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
    }
    
    if (mainCategory == "exports") {
      indicator <- input$exports
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      if (indicator == "monthly real") {
        updateSliderInput(session, "range_15",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_15
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "farm and fishing") {
        updateSliderInput(session, "range_16",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_16
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "energy") {
        updateSliderInput(session, "range_17",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_17
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "metal ores and minerals") {
        updateSliderInput(session, "range_18",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_18
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "metal products") {
        updateSliderInput(session, "range_19",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_19
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "industrial production") {
        updateSliderInput(session, "range_20",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_20
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "forestry") {
        updateSliderInput(session, "range_21",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_21
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "industrial m&e") {
        updateSliderInput(session, "range_22",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_22
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "electronic equipment") {
        updateSliderInput(session, "range_23",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_23
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "motor vehicles and parts") {
        updateSliderInput(session, "range_24",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_24
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "aircrafts") {
        updateSliderInput(session, "range_25",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_25
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "consumer goods") {
        updateSliderInput(session, "range_26",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_20
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
    }
    
    if (mainCategory == "imports") {
      indicator <- input$imports
      subset_table_1 <- data.frame(subset(subset_table, indicator == indicator))
      
      if (indicator == "monthly real") {
        updateSliderInput(session, "range_27",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_27
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "farm and fishing") {
        updateSliderInput(session, "range_28",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_28
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "energy") {
        updateSliderInput(session, "range_29",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_29
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "metal ores and minerals") {
        updateSliderInput(session, "range_30",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_30
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "metal products") {
        updateSliderInput(session, "range_31",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_31
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "industrial production") {
        updateSliderInput(session, "range_32",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_32
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "forestry") {
        updateSliderInput(session, "range_33",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_33
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "industrial m&e") {
        updateSliderInput(session, "range_34",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_34
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "electronic equipment") {
        updateSliderInput(session, "range_35",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_35
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "motor vehicles and parts") {
        updateSliderInput(session, "range_36",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_36
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "aircrafts") {
        updateSliderInput(session, "range_37",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_37
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
      if (indicator == "consumer goods") {
        updateSliderInput(session, "range_38",
                          min = min(as.Date(subset_table_1$date)),
                          max = max(as.Date(subset_table_1$date)))
        dateRange <- input$range_38
        subset_table_1 <- data.frame(subset(subset_table_1, date > dateRange[1]))
        subset_table_1 <- data.frame(subset(subset_table_1, date < dateRange[2]))
      }
    }
    
    subset_table_1 <- subset(subset_table_1, frequency == "MONTHLY")
    subset_table_1 <- subset_table_1[,c(4,1)]
    subset_table_1 <- subset_table_1[rev(order(subset_table_1$date)),]
    
    data_table <- subset_table_1
    #data_table$date <- as.integer(substring(subset_table_1$date,1,6))
    
    
    list(subset_table=subset_table_1, data_table=data_table)
  })
  
  output$plot1 <- renderPlot({
    if(nrow(commands1()$subset_table) > 0) {
    plot(x=commands1()$subset_table$date, y=commands1()$subset_table$value, type="n", xlab = "Time (Years)", ylab = "Fiscal Value ($)")
    lines(x=commands1()$subset_table$date, y=commands1()$subset_table$value, col="red", lwd = 5)
    title(main = "Fiscal Value as a function of Time - Yearly Reports")
    }
  })
  
  output$tableData1 <- renderTable(
    if(nrow(commands1()$subset_table) > 0) {
      head(commands1()$data_table,12)})
 
  output$text1 <- renderText(
    if(nrow(commands1()$subset_table) == 0) {
    "There are no Yearly Reports"})
  
  output$plot2 <- renderPlot({
    if(nrow(commands2()$subset_table) > 0) {
      plot(x=as.Date(commands2()$subset_table$date), y=commands2()$subset_table$value, type="n", xlab = "Time (Years)", ylab = "Fiscal Value ($)")
      lines(x=as.Date(commands2()$subset_table$date), y=commands2()$subset_table$value, col="blue", lwd = 5)
      title(main = "Fiscal Value as a function of Time - Quarterly Reports")
    }
  })
  output$tableData2 <- renderTable(
    if(nrow(commands2()$subset_table) > 0) {
      head(commands2()$data_table,12)})
  
  output$text2 <- renderText(
    if(nrow(commands2()$subset_table) == 0) {
      "There are no Quarterly Reports"})
  
  output$plot3 <- renderPlot({
    if(nrow(commands3()$subset_table) > 0) {
    plot(x=as.Date(commands3()$subset_table$date), y=commands3()$subset_table$value, type="n", xlab = "Time (Years)", ylab = "Fiscal Value ($)")
    lines(x=as.Date(commands3()$subset_table$date), y=commands3()$subset_table$value, col="green", lwd = 5)
    title(main = "Fiscal Value as a function of Time - Monthly Reports")
    }
  })
  output$tableData3 <- renderTable(
    if(nrow(commands3()$subset_table) > 0) {
      head(commands3()$data_table,12)})
 
  output$text3 <- renderText(
    if(nrow(commands3()$subset_table) == 0) {
      "There are no Monthly Reports"})
  
  output$download1 <- downloadHandler(filename = 'annually.csv', content = function(file) {write.csv(commands1()$data_table, file, row.names=FALSE)})
  output$download2 <- downloadHandler(filename = 'quarterly.csv', content = function(file) {write.csv(commands2()$data_table, file, row.names=FALSE)})
  output$download3 <- downloadHandler(filename = 'monthly.csv', content = function(file) {write.csv(commands3()$data_table, file, row.names=FALSE)})
  
  commandsPredict <- reactive({
    if(input$forecastBox_1) {
      xyz <- input$forecastLength_1
      print(xyz)
      p_load(forecast, tseries)
      
      #Create dataset
      if(input$tabselected == 1) {
        df <- commands1()$data_table
        df <- df[(order(df$date)),]
        
        freq<-1
      }
      if(input$tabselected == 2) {
        df <- commands2()$data_table
        df <- df[(order(df$date)),]
        freq<-4
      }
      if(input$tabselected == 3) {
        df <- commands3()$data_table
        df <- df[(order(df$date)),]
        
        freq<-12
      }
      
      #Create time series
      ts.gdp<-ts(data = df$value, start=c(as.integer((substring(df$date[1], 1,4))), as.integer(substring(df$date, 6, 7))), frequency = freq)
      ts.gdp<-diff(ts.gdp)
      adf.test(ts.gdp)
      #Clean
      ts.gdp<-tsclean(ts.gdp)
      #Smooth
      alpha<-HoltWinters(ts.gdp, beta=0, gamma=0)$alpha
      
      ExpSmooth<-function(x,alpha){
        #x- data;
        # alpha - smoothing parameter;
        n=length(x);
        Data=c(rep(0,n));
        Data[1]=x[1];
        for(i in 2:n){
          Data[i]=alpha*x[i]+(1-alpha)*Data[i-1]
        };
        out<-Data;
      }
      ts.gdp<-ExpSmooth(ts.gdp, alpha)
      
      #Fit to model
      Comparison.ts<-data.frame() 
      for(i in 0:5){
        for(j in 0:5){
          tryCatch({Obs<-data.frame()
          fit<-arima0(ts.gdp, order = c(i,0,j))
          Obs[1,1]<-i
          Obs[1,2]<-j
          Obs[1,3]<-fit$aic
          Comparison.ts<-rbind(Comparison.ts, Obs)},  error=function(e){})
        }
      }
      names(Comparison.ts)<-c("AR","MA", "AIC")
      
      
      #Find best model and save it
      Comparison.ts<-Comparison.ts[order(Comparison.ts$AIC),]
      fit<-arima0(ts.gdp, order=c(Comparison.ts[1,1], 0, Comparison.ts[1,2]))
      
      pred<-ts(predict(fit, n.ahead = xyz*freq)$pred, start=c(as.integer((substring(tail(df$date,1), 1,4))), as.integer(substring(tail(df$date,1), 6, 7))), frequency = freq)
      Final<-ts(c(ts.gdp,pred), start=start(ts.gdp), frequency=frequency(ts.gdp))
      
      Final<-diffinv(Final)
     
      Final<-data.frame(Value=as.matrix(Final), Date=time(Final)+1996)
     
      Final$Date<- paste(trunc(Final$Date),"-", str_pad(trunc((Final$Date%%1)*12+1), max(2), side="left", pad="0"), "-01",sep="" )
      Final
      print(Final)
      
    }
  })
  output$plot1 <- renderPlot({
    if(nrow(commands1()$subset_table) > 0) {
      plot(x=commands1()$subset_table$date, y=commands1()$subset_table$value, type="n", xlab = "Time (Years)", ylab = "Fiscal Value ($)")
      lines(x=commands1()$subset_table$date, y=commands1()$subset_table$value, col="red", lwd = 5)
      lines(x=commandsPredict()$Date, y=commandsPredict()$Value, col="green", lwd=5)
      title(main = "Fiscal Value as a function of Time - Yearly Reports")
    }
  })
  output$plot2 <- renderPlot({
    if(nrow(commands2()$subset_table) > 0) {
      plot(x=as.Date(commands2()$subset_table$date), y=commands2()$subset_table$value, type="n", xlab = "Time (Years)", ylab = "Fiscal Value ($)")
      lines(x=as.Date(commands2()$subset_table$date), y=commands2()$subset_table$value, col="blue", lwd = 5)
      lines(x=commandsPredict()$Date, y=commandsPredict()$Value, col="red", lwd=5)
      title(main = "Fiscal Value as a function of Time - Quarterly Reports")
    }
  })
  output$plot3 <- renderPlot({
    if(nrow(commands3()$subset_table) > 0) {
      plot(x=as.Date(commands3()$subset_table$date), y=commands3()$subset_table$value, type="n", xlab = "Time (Years)", ylab = "Fiscal Value ($)")
      lines(x=as.Date(commands3()$subset_table$date), y=commands3()$subset_table$value, col="green", lwd = 5)
      lines(x=commandsPredict()$Date, y=commandsPredict()$Value, col="blue", lwd=5)
      
      title(main = "Fiscal Value as a function of Time - Monthly Reports")
    }
  })
}

shinyApp(ui = ui, server = server)